?package(webapps):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="webapps" command="/usr/bin/webapps"
