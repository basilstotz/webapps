# Defaults for webapps initscript
# sourced by /etc/init.d/webapps
# installed at /etc/default/webapps by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
