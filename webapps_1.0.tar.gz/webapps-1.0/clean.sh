#!/bin/sh
rm ../webapps_1.0*
